const imagelist=[ 
    {
    id:"#1",
    img_location:"Portfolio_images/familycontacts.png",
    tech_img_location:["Portfolio_images/ajax.png","Portfolio_images/HTML.png","Portfolio_images/c-sharp.png"]
   },
   {
    id:"#2",
    img_location:"Portfolio_images/fiveEleven.png",
    tech_img_location:["Portfolio_images/angular.png","Portfolio_images/bootstrap.png"]
   },
   {
    id:"#3",
    img_location:"Portfolio_images/birthday.png",
    tech_img_location:["Portfolio_images/friedrice.png","Portfolio_images/mom2.png"]
   },
   {
    id:"#4",
    img_location:"Portfolio_images/lamode.png",
    tech_img_location:["Portfolio_images/bootstrap.png","Portfolio_images/django.png","Portfolio_images/HTML.png"]
   },
   {
    id:"#5",
    img_location:"Portfolio_images/familycontacts.png",
    tech_img_location:["Portfolio_images/ajax.png","Portfolio_images/bootstrap.png","Portfolio_images/c-sharp.png"]
   },
   {
    id:"#6",
    img_location:"Portfolio_images/fiveEleven.png",
    tech_img_location:["Portfolio_images/angular.png","Portfolio_images/c-sharp.png","Portfolio_images/HTML.png"]
   }
];

$(document).ready( function(){
/*     $('.container_timeline').click(function(){
        id = $(this).attr('id');
        console.log("id :",id);
        }); */
    $('#1').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[0].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[0].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
     //  $('#container_tech').hide();
    }) 
    $('#2').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[1].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[1].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
    //   $('#container_tech').hide();
    }) 
    $('#3').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[2].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[2].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
    //   $('#container_tech').hide();
    }) 
    $('#4').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[3].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[3].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
      // $('#container_tech').hide();
    }) 
    $('#5').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[4].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[4].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
     //  $('#container_tech').hide();
    })
    $('#6').click(function(){
        $('#container_tech').empty();
        var first_image= imagelist[5].img_location;
        $('#container_tech').append("<img src="+first_image+"></img>");
        var second_image = imagelist[5].tech_img_location;
        for(var i=0; i<second_image.length; i++){
            var MyImage= second_image[i];
            $('#container_tech').append("<img src="+MyImage+"></img>");
        }
        $('#container_tech').empty();
      // $('#container_tech').hide();
    })
    
})
                